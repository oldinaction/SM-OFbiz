https://github.com/Lightstreamer/Lightstreamer-example-chat-client-javascript
https://github.com/Lightstreamer/Lightstreamer-example-Chat-adapter-java